# Receptor ASV - revisión B preliminar

Fecha: 2026-10-05. Proyecto editable para KiCad 10; PDF A3 de una página incluido.

## Archivos

- `ReceptorASV.kicad_pro`: proyecto de KiCad.
- `ReceptorASV.kicad_sch`: esquema completo del receptor.
- `ReceptorASV.pdf`: copia para revisión.
- `ASV_Receptor.kicad_sym`, `ASV_Receptor.pretty`, `sym-lib-table`, `fp-lib-table`: símbolos y huellas locales.
- `documentacion/BOM.md`: componentes y encapsulados seleccionados.
- `documentacion/ERC.rpt`: resultado del control eléctrico.
- `documentacion/ReceptorASV.xml`: netlist exportada por KiCad.
- `documentacion/validacion_netlist.txt`: cotejo de conexiones exportadas.
- `generar_receptor.py`: generador reproducible. Ejecutarlo sobrescribe los archivos generados; después de editar manualmente el esquema, no ejecutarlo sin guardar esos cambios.

## Lectura del esquema

La revisión B conecta todos los componentes mediante cables continuos, incluida la alimentación y la masa común. Las etiquetas solo nombran señales; se verificó en una copia sin etiquetas que las redes siguen completas. Un punto indica unión; un cruce sin punto no conecta. Los pines del ESP32 se agrupan por función en el dibujo, manteniendo sus números eléctricos y de huella. La versión anterior está guardada en `documentacion/revision_A_etiquetas.zip`.

## Alcance y estado

Es un esquemático para desarrollar la PCB del receptor. No incluye una PCB colocada/ruteada ni Gerbers. No se realizó ensayo físico. ERC no comprueba compatibilidad mecánica, pinout real del módulo ni funcionamiento RF.

La foto más reciente identifica **SX1278 / 433 MHz**, corrigiendo la referencia inicial a SX1276. La forma y dimensiones son compatibles con XL1278-SMT; la identificación exacta del módulo y la orientación de los contactos siguen pendientes de cotejo con la unidad física o documentación del proveedor.

Se emplea una referencia de **16 contactos** del XL1278-SMT. El símbolo anterior de `EmisorASV/ASV_Custom.kicad_sym` tiene solo 12 y asigna ANT al 12. En la referencia XL1278-SMT, el 12 es GND y ANT es el 16. El proyecto del emisor no fue modificado. **No reutilizar su asignación ANT=12 para este receptor.**

Las huellas U3 y U4 llevan `VERIFICAR` en el nombre: imprimir a escala 1:1 y cotejar ancho, longitud, paso, orientación, número de contactos y centros con las placas reales antes de liberar fabricación. Las dimensiones globales y el paso no bastan para certificar una huella.

## Alimentación

Batería de la foto: TAIYO TYD12-33, AGM/VRLA, nominal 12 V y 33 Ah. Entrada de diseño: 10,5–14,7 V; verificar condiciones reales de carga y funcionamiento.

1. J1: pin 1 positivo, pin 2 negativo/GND.
2. F1: fusible 1 A, tensión nominal DC de al menos 32 V. Añadir un fusible de cable cerca del borne positivo de la batería; F1 en la PCB no protege el tramo anterior a ella. Validar calibre y curva frente a arranque y cableado.
3. D1 SS34 en serie: protección de polaridad. D2 SMBJ16A unidireccional: cátodo a VIN_PROT y ánodo a GND.
4. U1 RECOM R-78E5.0-1.0: buck 5 V/1 A, entrada especificada 8–28 V. La huella de KiCad R-78E-0.5 comparte el cuerpo de 11,6 × 8,5 mm y el paso de 2,54 mm; confirmar contra el componente comprado.
5. JP1 conecta la salida del buck a SYS_5V, que alimenta el pin 5V del DevKit y el LDO del radio.
6. U2 TLV75533PDBVR: 3,3 V exclusivos para el LoRa. No unir esta salida con el 3V3 del DevKit.

Presupuesto de trabajo: reservar aproximadamente 0,7 A a 5 V para ESP32 y radio, dentro de 1 A nominal del buck; medir picos reales y revisar temperatura. La capacidad adicional prevista en SYS_5V es 57 µF, más la del DevKit, y debe mantenerse dentro de los 220 µF especificados por RECOM. El LDO está destinado al radio, no a alimentar las STM32. A 140 mA su disipación aproximada es (5–3,3) × 0,14 = 0,24 W; verificar temperatura y cobre de disipación si se habilita transmisión.

Este circuito no carga la batería ni incluye corte por descarga profunda. RECOM recomienda una fuente con arranque suave: verificar sobreimpulso e inrush en el arranque con batería/cable reales y añadir limitación de arranque si el ensayo lo exige. La selección de TVS no constituye una validación de transitorios de un sistema con motores.

### Programación USB

**Retirar JP1 antes de conectar USB al DevKit.** Con JP1 retirado, se prevé que USB alimente SYS_5V desde el pin 5V del DevKit y también alimente el radio. Esa ruta debe confirmarse en el esquema del DevKit real, pues existen clones diferentes. No conectar USB con JP1 instalado. El diseño no incluye selección automática entre USB y batería.

## ESP32 y señales

Referencia tomada del proyecto existente: ESP32 DevKitC de 38 pines con módulo WROOM, montado mediante dos hileras sobre la PCB. Huella candidata: paso 2,54 mm, separación entre hileras 25,4 mm. Confirmar antes de fabricar; los DevKit de 30 pines no son intercambiables. GPIO16/17 requieren un WROOM compatible: en variantes WROVER pueden estar ocupados por PSRAM.

| Función | GPIO ESP32 | Contacto XL1278-SMT de referencia |
|---|---:|---:|
| SCK | 18 | 8 |
| MISO | 19 | 6 |
| MOSI | 23 | 7 |
| NSS / CS | 27 | 9 |
| RESET | 14 | 11 |
| DIO0 | 26 | 10 |
| DIO1 | 25 | 2 |
| DIO2 | 33 | 3 |
| VCC radio | LORA_3V3 | 5 |
| GND | GND común | 1, 12, 15 |
| Antena | RF_433 | 16 |
| DIO3 / DIO4 / DIO5 | sin conectar | 4 / 13 / 14 |

R1 mantiene NSS alto durante el arranque y R2 mantiene RESET alto. C7 de 100 nF y C8 de 10 µF deben ubicarse junto a VCC/GND del radio. Configurar SPI y UART explícitamente en firmware; GPIO21/22 se usan como UART, no como I2C.

## Dos placas STM32 por UART

Supuesto de interfaz: señales UART CMOS/TTL de 3,3 V, placas STM32 con alimentación propia y GND común. Falta el modelo exacto de las placas para confirmar sus conectores, niveles y pines UART. No se entrega alimentación por J2/J3. No conectar una interfaz RS-232, RS-485 ni TX de 5 V directamente.

| Conector receptor | Pin 1 | Pin 2 | Pin 3 | UART ESP32 |
|---|---|---|---|---|
| J2 / STM32 1 | GND | TX del ESP → RX STM32 | RX del ESP ← TX STM32 | UART1, TX GPIO21 / RX GPIO22 |
| J3 / STM32 2 | GND | TX del ESP → RX STM32 | RX del ESP ← TX STM32 | UART2, TX GPIO17 / RX GPIO16 |

Los nombres EXT1_RX/EXT1_TX y EXT2_RX/EXT2_TX están desde el punto de vista de la STM32. Las resistencias serie de 100 Ω no convierten tensión. Las interfaces se prevén para conexiones cortas internas; si los cables salen de la caja o son largos, evaluar protección y un enlace diferencial. UART0/GPIO1/GPIO3 queda reservado al USB del DevKit.

## LoRa y antena

U4 es el módulo completo soldado SMD, no el chip SX1278 individual. La huella candidata contiene 16 pads SMD, paso principal 1,27 mm, cuerpo de referencia 16,5 × 17 mm y pads de 2,4 × 0,9 mm. Las posiciones provienen de la geometría publicada por el autor del breakout XL1278-SMT, no de medición del módulo del usuario. Se dibujó una huella local nueva únicamente SMD; verificar también la soldabilidad de DIO4/DIO5 y cualquier contacto inferior.

J4 es una alternativa de antena SMA externa. **Usar una sola antena:** si se usa la de resorte directamente en el módulo, no montar J4 y evitar un ramal RF innecesario en el layout. Si se elige J4, retirar la antena del módulo, llevar RF_433 con una pista corta de 50 Ω y dimensionarla según stackup del fabricante; no se fija un ancho sin ese dato. Mantener el área de radiación libre según la antena elegida y ubicarla lejos del buck, cables y metal.

## Comprobaciones antes de liberar fabricación

- Confirmar DevKit WROOM de 38 pines, pin 1, separación de hileras y alimentación USB/5V.
- Confirmar referencia XL1278-SMT y su pinout de 16 contactos; foto nítida de ambas caras o plano del proveedor.
- Verificar huellas 1:1 y alturas, acceso al USB, bornera y antena.
- Confirmar modelo/conectores de las dos STM32, UART de 3,3 V y alimentación propia.
- Realizar layout, DRC, verificación de RF, ensayo de fuente con límite de corriente y prueba de enlace antes de generar Gerbers.

## Fuentes

- Evidencias del usuario: capturas de batería TAIYO TYD12-33, dimensiones/paso del módulo y publicación SX1278 433 MHz.
- Proyecto existente: `../EmisorASV/EmisorASV.kicad_sch`, utilizado para identificar la referencia DevKit y detectar la discrepancia del símbolo LoRa.
- Espressif DevKitC V4: https://docs.espressif.com/projects/esp-dev-kits/en/latest/esp32/esp32-devkitc/user_guide.html
- Semtech SX1278: https://www.semtech.com/products/wireless-rf/lora-connect/sx1278
- RECOM R-78E-1.0: https://recom-power.com/pdf/Innoline/R-78E-1.0.pdf
- TI TLV755P: https://www.ti.com/lit/ds/symlink/tlv755p.pdf
- Vishay SMBJ: https://www.vishay.com/docs/88392/smbj.pdf
- Referencia técnica del autor de un breakout XL1278-SMT (no documentación oficial del módulo del usuario): https://github.com/matburnham/lora-breakout
- Pinout publicado por el autor: https://github.com/matburnham/kicad-libs/blob/main/symbols/Misc%20RF.lib
- Geometría publicada por el autor: https://github.com/matburnham/kicad-libs/blob/main/footprints/Misc%20RF.pretty/XL1278-SMT.kicad_mod

La referencia técnica secundaria respecto del fabricante se utiliza como hipótesis documentada. No sustituye el cotejo físico. Las bibliotecas estándar de componentes provienen de la instalación de KiCad.
