#!/usr/bin/env python3
"""Genera el esquema KiCad y bibliotecas locales del receptor ASV (revision B preliminar)."""
from pathlib import Path
import re, json, uuid, math, copy
BASE=Path(__file__).resolve().parent
STD=Path('/Applications/KiCad/KiCad.app/Contents/SharedSupport/symbols')
q=lambda s:json.dumps(str(s),ensure_ascii=False)
u=lambda:str(uuid.uuid4())
def parse(s):
 ts=iter(re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',s))
 def sub():
  out=[]
  for t in ts:
   if t=='(':out.append(sub())
   elif t==')':return out
   else:out.append(t)
  return out
 return sub()[0]
def dump(x):return '('+' '.join(map(dump,x))+')' if isinstance(x,list) else str(x)
def child(x,key):return next((t for t in x if isinstance(t,list) and t[0]==key),None)
def kids(x,key):return [t for t in x if isinstance(t,list) and t[0]==key]
def val(x):return json.loads(x) if x.startswith('"') else x
libs={}; custom={}
def standard(lib,name):
 key=lib+':'+name
 if key in libs:return key
 root=parse((STD/(lib+'.kicad_sym')).read_text())
 syms={val(t[1]):t for t in kids(root,'symbol')}
 def expand(n):
  s=copy.deepcopy(syms[n]); ext=child(s,'extends')
  if ext:
   parentname=val(ext[1]); parent=expand(parentname)
   ownprops={val(p[1]) for p in kids(s,'property')}
   body=[t for t in parent[2:] if not (isinstance(t,list) and (t[0]=='property' and val(t[1]) in ownprops))]
   for t in body:
    if isinstance(t,list) and t[0]=='symbol':t[1]=q(val(t[1]).replace(parentname+'_',n+'_'))
   s=['symbol',q(n)]+body+[t for t in s[2:] if not(isinstance(t,list) and t[0]=='extends')]
  return s
 s=expand(name);s[1]=q(key);libs[key]=s;return key
def block(name,pins,w,h):
 # pins: number, name, electrical type, side L/R/T/B, local coordinate along side
 s=['symbol',q(name),['pin_names',['offset','0.8']],['in_bom','yes'],['on_board','yes']]
 for n,v in [('Reference','U'),('Value',name),('Footprint',''),('Datasheet','')]:
  s.append(parse(f'(property {q(n)} {q(v)} (at 0 0 0) (effects (font (size 1.27 1.27)) (hide yes)))'))
 s.append(parse(f'(symbol {q(name+"_0_1")} (rectangle (start {-w} {h}) (end {w} {-h}) (stroke (width 0.254) (type default)) (fill (type background))))'))
 body=['symbol',q(name+'_1_1')]
 for num,pn,typ,side,co in pins:
  x,y,ang={'L':(-w-5.08,co,0),'R':(w+5.08,co,180),'T':(co,h+5.08,270),'B':(co,-h-5.08,90)}[side]
  body.append(parse(f'(pin {typ} line (at {x} {y} {ang}) (length 5.08) (name {q(pn)} (effects (font (size 1.016 1.016)))) (number {q(num)} (effects (font (size 0.889 0.889)))))'))
 s.append(body);custom[name]=copy.deepcopy(s);s[1]=q('ASV_Receptor:'+name);libs['ASV_Receptor:'+name]=s;return 'ASV_Receptor:'+name
# Pins retain their original electrical/footprint numbers; regrouped to make wiring legible.
left=['3V3','EN','GPIO36','GPIO39','GPIO34','GPIO35','GPIO32','GPIO33','GPIO25','GPIO26','GPIO27','GPIO14','GPIO12','GND','GPIO13','SD2','SD3','CMD','5V']
right=['GND','GPIO23','GPIO22','TX0','RX0','GPIO21','GND','GPIO19','GPIO18','GPIO5','GPIO17','GPIO16','GPIO4','GPIO0','GPIO2','GPIO15','SD1','SD0','CLK']
names={str(i+1):n for i,n in enumerate(left+right)}
sig_order=[('28','18 / SCK'),('21','23 / MOSI'),('27','19 / MISO'),('11','27 / NSS'),('12','14 / RESET'),('10','26 / DIO0'),('9','25 / DIO1'),('8','33 / DIO2')]
spi_y=[round(129.54+i*7.62,4) for i in range(8)]
pins=[(n,name,'bidirectional','R',round(171.45-y,4)) for (n,name),y in zip(sig_order,spi_y)]
for n,name,y in [('25','21 / TX1',198.12),('22','22 / RX1',205.74),('30','17 / TX2',220.98),('31','16 / RX2',228.6)]:
 pins.append((n,name,'bidirectional','R',round(171.45-y,4)))
pins += [('19','5V','power_in','T',0),('14','GND','power_in','B',-10.16),('20','GND','power_in','B',0),('26','GND','power_in','B',10.16)]
used={p[0] for p in pins}
for i,(n,name) in enumerate((n,name) for n,name in names.items() if n not in used):
 typ='power_out' if name=='3V3' else 'input' if name in ['EN','GPIO36','GPIO39','GPIO34','GPIO35'] else 'bidirectional'
 pins.append((n,name,typ,'L',round(53.34-i*3.81,4)))
esp=block('DevKitC_38P_VERIFICAR',pins,20.32,60.96)
loras=[('8','SCK','input'),('7','MOSI','input'),('6','MISO','output'),('9','NSS','input'),('11','RESET','input'),('10','DIO0','bidirectional'),('2','DIO1','bidirectional'),('3','DIO2','bidirectional')]
lp=[(n,name,typ,'L',round(157.48-y,4)) for (n,name,typ),y in zip(loras,spi_y)]
lp += [('5','VCC 3V3','power_in','T',0),('16','ANT','passive','R',27.94),('4','DIO3','bidirectional','R',15.24),('13','DIO4','bidirectional','R',10.16),('14','DIO5','bidirectional','R',5.08),('1','GND','power_in','R',-13.97),('12','GND','power_in','R',-21.59),('15','GND RF','power_in','R',-29.21)]
lora=block('XL1278_SMT_433_VERIFICAR',lp,20.32,38.1)
buck=block('R78E5V_1A',[('1','VIN','power_in','L',0),('3','5V OUT','power_out','R',0),('2','GND','power_in','B',0)],13.97,7.62)
ldo=block('TLV75533PDBV',[('1','IN','power_in','L',2.54),('3','EN','input','L',-2.54),('5','OUT','power_out','R',2.54),('2','GND','power_in','B',0),('4','NC','no_connect','R',-2.54)],10.16,6.35)
uart=block('UART_3V3',[('2','A RX STM32','passive','L',3.81),('3','DE TX STM32','passive','L',-3.81),('1','GND','passive','R',0)],13.97,8.89)
bat=block('BATERIA_12V',[('1','BAT+','passive','R',2.54),('2','BAT-','passive','R',-2.54)],7.62,6.35)
jump=block('Puente_2P',[('1','1','passive','L',0),('2','2','passive','R',0)],2.54,2.54)
for n in ['R','C','C_Polarized','D_Schottky','D_Zener','Fuse']:standard('Device',n)
standard('Connector','Conn_Coaxial');standard('power','PWR_FLAG')
root=u(); elements=[]; instances={}; bom=[]
def fx(size=1.27,justify=''):return f'(effects (font (size {size} {size}))'+(f' (justify {justify})' if justify else '')+')'
def note(txt,x,y,size=1.27):elements.append(f'(text {q(txt)} (at {x} {y} 0) {fx(size,"left top")} (uuid {q(u())}))')
def wire(p1,p2):
 if p1==p2:return
 elements.append(f'(wire (pts (xy {p1[0]} {p1[1]}) (xy {p2[0]} {p2[1]})) (stroke (width 0.2032) (type default)) (uuid {q(u())}))')
def label(net,p,side='R'):
 elements.append(f'(label {q(net)} (at {p[0]} {p[1]} 0) {fx(1.27,"right bottom" if side=="L" else "left bottom")} (uuid {q(u())}))')
def put(key,ref,value,x,y,rot=0,foot='',datasheet='',props=None):
 sym=libs[key]; iid=u(); pts={}; angles={}
 for body in kids(sym,'symbol'):
  for p in kids(body,'pin'):
   a=child(p,'at'); px,py=float(a[1]),float(a[2]); rad=math.radians(rot)
   coord=(round(x+px*math.cos(rad)-py*math.sin(rad),4),round(y-py*math.cos(rad)-px*math.sin(rad),4))
   num=val(child(p,'number')[1]);pts[num]=coord;angles[num]=(float(a[3])+rot)%360
 # Use generous property separation for blocks; small parts put labels beside vertical bodies.
 if props is None:
  if key.startswith('ASV_Receptor:'):
   hh={'DevKitC_38P_VERIFICAR':38.1,'XL1278_SMT_433_VERIFICAR':27.94,'R78E5V_1A':7.62,'TLV75533PDBV':6.35,'UART_3V3':7.62,'BATERIA_12V':6.35}[key.split(':')[1]]
   props=[(x,y-hh-7.62),(x,y-hh-3.81)]
  elif key in ['Device:C','Device:C_Polarized','Device:R','Device:Fuse'] and rot==0:props=[(x+4,y-1.27),(x+4,y+1.27)]
  else:props=[(x,y-7.62),(x,y-3.81)]
 ps=''
 for k,v,pos,hide in [('Reference',ref,props[0],False),('Value',value,props[1],False),('Footprint',foot,(x,y),True),('Datasheet',datasheet,(x,y),True)]:
  just='left' if key in ['Device:C','Device:C_Polarized','Device:R','Device:Fuse'] and rot==0 and not hide else ''
  effects=fx(1.27,just)
  if hide:effects=effects[:-1]+' (hide yes))'
  ps+=f'(property {q(k)} {q(v)} (at {pos[0]} {pos[1]} {90 if rot in (90,270) else 0}) {effects})'
 pn=''.join(f'(pin {q(n)} (uuid {q(u())}))' for n in pts)
 elements.append(f'(symbol (lib_id {q(key)}) (at {x} {y} {rot}) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {q(iid)}) {ps} {pn} (instances (project "ReceptorASV" (path {q("/"+root)} (reference {q(ref)}) (unit 1)))))')
 instances[ref]={'pins':pts,'angles':angles,'nets':{},'value':value,'footprint':foot}
 if not ref.startswith('#'):bom.append((ref,value,foot))
 return ref
def connect(ref,pin,net,length=5.08):
 pin=str(pin);i=instances[ref];p=i['pins'][pin];ang=i['angles'][pin]
 dx,dy={0:(-1,0),180:(1,0),90:(0,1),270:(0,-1)}[ang]
 e=(round(p[0]+length*dx,4),round(p[1]+length*dy,4));wire(p,e);label(net,e,'L' if dx<0 else 'R');i['nets'][pin]=net
 return e
def nc(ref,pin):
 p=instances[ref]['pins'][str(pin)];elements.append(f'(no_connect (at {p[0]} {p[1]}) (uuid {q(u())}))');instances[ref]['nets'][str(pin)]='NC'
def flag(ref,x,y,net):
 put('power:PWR_FLAG',ref,'PWR_FLAG',x,y,props=[(x,y-5),(x,y-2)])
 connect(ref,'1',net,2.54)
CAP='Capacitor_SMD:C_0805_2012Metric';RES='Resistor_SMD:R_0805_2012Metric'
# Revision B: all connections are continuous drawn wires, including supply and ground.
segments=[]
def wire(p1,p2):
 p1=tuple(round(v,4) for v in p1);p2=tuple(round(v,4) for v in p2)
 if p1==p2:return
 assert p1[0]==p2[0] or p1[1]==p2[1],(p1,p2)
 segments.append((p1,p2))
def route(*pts):
 for a,b in zip(pts,pts[1:]):wire(a,b)
def pp(ref,pin):return instances[ref]['pins'][str(pin)]
def mark(ref,pin,net):instances[ref]['nets'][str(pin)]=net
def link(ra,pa,rb,pb,net,via=()):
 route(pp(ra,pa),*via,pp(rb,pb));mark(ra,pa,net);mark(rb,pb,net)
def tap(ref,pin,net,target,via=()):
 route(pp(ref,pin),*via,target);mark(ref,pin,net)

note('RECEPTOR ASV - CONEXIONES COMPLETAS',15.24,12.7,2.54)
note('Bateria 12 V  >  regulacion 5 V / 3,3 V  >  ESP32 + LoRa  >  dos STM32',15.24,20.32,1.524)
# 1. Continuous power chain.
put(bat,'J1','BATERIA 12 V / 33 Ah',25.4,45.72,foot='TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal',props=[(25.4,29.21),(25.4,33.02)])
put('Device:Fuse','F1','1 A / >=32 V',63.5,43.18,90,'Fuse:Fuse_1206_3216Metric')
put('Device:D_Schottky','D1','SS34',91.44,43.18,180,'Diode_SMD:D_SMA')
put('Device:D_Zener','D2','SMBJ16A',116.84,63.5,270,'Diode_SMD:D_SMB',props=[(126,61),(126,64.81)])
put('Device:C_Polarized','C1','47u / 50 V',142.24,63.5,foot='Capacitor_THT:CP_Radial_D6.3mm_P2.50mm')
put('Device:C','C2','10u / 50 V',167.64,63.5,foot='Capacitor_SMD:C_1210_3225Metric')
put(buck,'U1','12 V a 5 V / R-78E5.0-1.0',205.74,43.18,foot='Converter_DCDC:Converter_DCDC_RECOM_R-78E-0.5_THT',datasheet='https://recom-power.com/pdf/Innoline/R-78E-1.0.pdf',props=[(205.74,29.21),(205.74,33.02)])
put(jump,'JP1','PUENTE',246.38,43.18,foot='Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical',props=[(246.38,32),(246.38,36)])
put('Device:C','C3','10u / 10 V',266.7,63.5,foot=CAP)
put('Device:C_Polarized','C4','47u / 10 V',292.1,63.5,foot='Capacitor_THT:CP_Radial_D5.0mm_P2.00mm')
put('Device:C','C5','1u / 10 V',317.5,68.58,foot=CAP)
put(ldo,'U2','5 V a 3,3 V / TLV75533',340.36,45.72,foot='Package_TO_SOT_SMD:SOT-23-5',datasheet='https://www.ti.com/lit/ds/symlink/tlv755p.pdf',props=[(348,30.48),(348,34.29)])
put('Device:C','C6','10u / 10 V',375.92,63.5,foot=CAP)
link('J1',1,'F1',1,'BAT_POS');link('F1',2,'D1',2,'BAT_FUSED');link('D1',1,'U1',1,'VIN_PROT')
link('U1',3,'JP1',1,'BUCK_5V');link('JP1',2,'U2',1,'SYS_5V')
for ref in ['D2','C1','C2']:
 tap(ref,1,'VIN_PROT',(pp(ref,1)[0],43.18))
for ref in ['C3','C4','C5']:
 tap(ref,1,'SYS_5V',(pp(ref,1)[0],43.18))
tap('U2',3,'SYS_5V',(322.58,43.18),via=[(322.58,48.26)])
nc('U2',4)
route(pp('U2',5),(398.78,43.18),(398.78,95.25),(180.34,95.25));mark('U2',5,'LORA_3V3')
tap('C6',1,'LORA_3V3',(375.92,43.18))
# Whole-sheet common ground, continuously connected to battery minus.
route(pp('J1',2),(38.1,83.82),(375.92,83.82));mark('J1',2,'GND')
route((38.1,83.82),(17.78,83.82),(17.78,248.92),(393.7,248.92))
for ref,pin in [('D2',2),('C1',2),('C2',2),('U1',2),('C3',2),('C4',2),('C5',2),('U2',2),('C6',2)]:
 tap(ref,pin,'GND',(pp(ref,pin)[0],83.82))
label('BAT_POS',(43.18,43.18));label('BAT_FUSED',(69.85,43.18));label('VIN_PROT',(149.86,43.18));label('BUCK_5V',(226.06,43.18));label('SYS_5V',(280.67,43.18));label('LORA_3V3',(360.68,95.25));label('GND',(43.18,248.92))
note('JP1: abrir antes de conectar USB.',231.14,24.13,1.27)
# 2. ESP32 and radio with aligned, straight SPI/control wires.
put(esp,'U3','ESP32 DevKitC 38 pines',101.6,171.45,foot='ASV_Receptor:DevKitC_38P_P2.54_W25.4_VERIFICAR',props=[(66.04,106.68),(66.04,110.49)])
put(lora,'U4','LoRa SX1278 / 433 MHz',269.24,157.48,foot='ASV_Receptor:XL1278_SMT_SMD_VERIFICAR',props=[(301,107.95),(301,111.76)])
tap('U3',19,'SYS_5V',(279.4,43.18),via=[(101.6,100.33),(279.4,100.33)])
tap('U4',5,'LORA_3V3',(269.24,95.25))
for (ep,_),(lp,name,_),y in zip(sig_order,loras,spi_y):
 link('U3',ep,'U4',lp,'LORA_'+name)
 label('LORA_'+name,(137.16,y))
# Pull-ups connected to the 3.3 V rail and their actual signal wires.
for ref,x,signal,y in [('R1',180.34,'NSS',spi_y[3]),('R2',205.74,'RESET',spi_y[4])]:
 put('Device:R',ref,'10k',x,114.3,foot=RES)
 tap(ref,1,'LORA_3V3',(x,95.25));tap(ref,2,'LORA_'+signal,(x,y))
# Radio ground rail lies outside the UART signal paths.
for pin in [1,12,15]:
 pt=pp('U4',pin);tap('U4',pin,'GND',(312.42,pt[1]))
route((312.42,171.45),(312.42,190.5),(393.7,190.5),(393.7,248.92))
for pin in [4,13,14]:nc('U4',pin)
for pin in [14,20,26]:tap('U3',pin,'GND',(pp('U3',pin)[0],248.92))
for pin in instances['U3']['pins']:
 if pin not in instances['U3']['nets'] and pin not in ['25','22','30','31']:nc('U3',pin)
put('Connector:Conn_Coaxial','J4','ANTENA 433 MHz',337.82,129.54,foot='Connector_Coaxial:SMA_Amphenol_132289_EdgeMount',props=[(337.82,117.475),(337.82,121.285)])
link('U4',16,'J4',1,'RF_433');label('RF_433',(303.53,129.54));tap('J4',2,'GND',(337.82,190.5))
for ref,x,value in [('C7',355.6,'100n / 10 V'),('C8',381,'10u / 10 V')]:
 put('Device:C',ref,value,x,160.02,foot=CAP)
 tap(ref,1,'LORA_3V3',(x,95.25));tap(ref,2,'GND',(x,190.5))
note('C7/C8 junto al modulo.',347.98,181.61,1.27)
# 3. UART1 and UART2: visible wires go to the corresponding STM32 connector.
for n,y in [(1,201.93),(2,224.79)]:
 ref='J'+str(n+1)
 put(uart,ref,'STM32 '+str(n),370.84,y,foot='Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical',props=[(359.41,y-7.62),(374.65,y-7.62)])
 # Pin 2 is ESP TX -> STM32 RX, pin 3 is STM32 TX -> ESP RX.
 for j,(ep,pin) in enumerate([('25' if n==1 else '30',2),('22' if n==1 else '31',3)]):
  yy=pp(ref,pin)[1];rr='R'+str(3+(n-1)*2+j)
  put('Device:R',rr,'100R',231.14,yy,90,RES,props=[(223,yy-2.54),(238,yy-2.54)])
  link('U3',ep,rr,1,f'UART{n}_'+('TX' if j==0 else 'RX'))
  link(rr,2,ref,pin,f'EXT{n}_'+('RX' if j==0 else 'TX'))
  label(f'UART{n}_'+('TX' if j==0 else 'RX'),(137.16,yy))
  label(f'EXT{n}_'+('RX' if j==0 else 'TX'),(299.72,yy))
 gp=pp(ref,1);tap(ref,1,'GND',(393.7,gp[1]))
# Source flags are placed on the existing wires, without remote labels.
for ref,x,y,net in [('#FLG01',52.07,83.82,'GND'),('#FLG02',130.81,43.18,'VIN_PROT'),('#FLG03',307.34,43.18,'SYS_5V')]:
 put('power:PWR_FLAG',ref,'PWR_FLAG',x,y,props=[(x,y-8),(x,y-3.81)])
 mark(ref,1,net)
note('COMO LEERLO',25.4,257.81,1.524)
note('Todos los enlaces estan dibujados con cables. Punto = union electrica.\nCruce sin punto = cables separados. TX del ESP va a RX de cada STM32.\nLas STM32 tienen alimentacion propia; J2/J3 llevan TX, RX y GND.\nReferencia preliminar: cotejar huellas DevKit/LoRa antes de fabricar.\nFusible de cable junto a bateria. J4 solo si se retira la antena del modulo.',25.4,264.16,1.27)
# Split conductors at branch endpoints, add explicit junctions only where conductors join.
ends={p for seg in segments for p in seg}
ends.update(p for inst in instances.values() for p in inst['pins'].values())
for item in elements:
 node=parse(item)
 if node[0]=='label':
  a=child(node,'at');ends.add((float(a[1]),float(a[2])))
edges=set()
for a,b in segments:
 cuts=[p for p in ends if (a[0]==b[0]==p[0] and min(a[1],b[1])<=p[1]<=max(a[1],b[1])) or (a[1]==b[1]==p[1] and min(a[0],b[0])<=p[0]<=max(a[0],b[0]))]
 cuts.sort()
 for p1,p2 in zip(cuts,cuts[1:]):edges.add(tuple(sorted((p1,p2))))
from collections import Counter
deg=Counter(p for seg in edges for p in seg)
for p,d in deg.items():
 if d>=3:elements.append(f'(junction (at {p[0]} {p[1]}) (diameter 0.762) (color 0 0 0 0) (uuid {q(u())}))')
for p1,p2 in sorted(edges):
 elements.append(f'(wire (pts (xy {p1[0]} {p1[1]}) (xy {p2[0]} {p2[1]})) (stroke (width 0.2032) (type default)) (uuid {q(u())}))')
# Serialize self-contained schematic and local symbol library.
header=f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {q(root)}) (paper "A3") (title_block (title "ASV - Receptor LoRa 433 MHz") (date "2026-10-05") (rev "B") (company "UCC - ASV") (comment 1 "Bateria AGM 12 V / ESP32 DevKit / dos UART 3V3") (comment 2 "Huellas U3 y U4 requieren cotejo fisico"))'
(BASE/'ReceptorASV.kicad_sch').write_text(header+'\n(lib_symbols\n'+'\n'.join(dump(s) for s in libs.values())+')\n'+'\n'.join(elements)+f'\n(sheet_instances (path "/" (page "1")))\n)\n')
(BASE/'ASV_Receptor.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor")\n'+'\n'.join(dump(s) for s in custom.values())+'\n)')
(BASE/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "ASV_Receptor") (type "KiCad") (uri "${KIPRJMOD}/ASV_Receptor.kicad_sym") (options "") (descr "Simbolos locales receptor ASV")))\n')
(BASE/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "ASV_Receptor") (type "KiCad") (uri "${KIPRJMOD}/ASV_Receptor.pretty") (options "") (descr "Huellas de referencia: verificar antes de fabricar")))\n')
if not (BASE/'ReceptorASV.kicad_pro').exists():
 (BASE/'ReceptorASV.kicad_pro').write_text(json.dumps({'meta':{'filename':'ReceptorASV.kicad_pro','version':1},'net_settings':{'classes':[{'name':'Default','clearance':0.2,'track_width':0.25,'via_diameter':0.6,'via_drill':0.3,'microvia_diameter':0.3,'microvia_drill':0.1,'diff_pair_width':0.2,'diff_pair_gap':0.25,'diff_pair_via_gap':0.25}],'meta':{'version':4}}},indent=2))
# Own footprint construction from documented reference geometry; no invented claim of manufacturing validation.
fpdir=BASE/'ASV_Receptor.pretty';fpdir.mkdir(exist_ok=True)
def fpstart(name,desc,attr):return f'(footprint {q(name)} (version 20241229) (generator "pcbnew") (layer "F.Cu") (descr {q(desc)}) (attr {attr})\n(property "Reference" "REF**" (at 0 -11 0) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))))\n(property "Value" {q(name)} (at 0 12 0) (layer "F.Fab") (effects (font (size 0.8 0.8) (thickness 0.12))))\n'
def rect(x1,y1,x2,y2,layer,width=0.1):return f'(fp_rect (start {x1} {y1}) (end {x2} {y2}) (stroke (width {width}) (type default)) (fill none) (layer {q(layer)}))\n'
name='XL1278_SMT_SMD_VERIFICAR'
f=fpstart(name,'REFERENCIA NO LIBERADA. XL1278-SMT 16 contactos. 16.5x17mm, paso 1.27. Cotejar modulo fisico. Geometria referencia: matburnham/kicad-libs.','smd')
# Local coordinates translated from measured reference; origin is the body center.
ox,oy=6.985,7.7
f+=rect(-8.25,-8.5,8.25,8.5,'F.Fab')+rect(-9.65,-9,9.65,10,'F.CrtYd',0.05)
f+='(fp_line (start -7 -8.75) (end 7 -8.75) (stroke (width 0.12) (type default)) (layer "F.SilkS"))\n'
f+='(fp_text user "VERIFICAR" (at 0 0) (layer "F.Fab") (effects (font (size 1 1) (thickness 0.15))))\n'
coords={i:(-0.8,(i-1)*1.27,0) for i in range(1,13)}
coords.update({13:(0.37,16.029,90),14:(1.64,16.029,90),15:(14.748,1.27,0),16:(14.748,0,0)})
for num,(x,y,a) in coords.items():
 f+=f'(pad {q(num)} smd roundrect (at {round(x-ox,4)} {round(y-oy,4)} {a}) (size 2.4 0.9) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.2))\n'
f+='(fp_circle (center -9.5 -7.7) (end -9.25 -7.7) (stroke (width 0.15) (type default)) (fill none) (layer "F.SilkS"))\n)\n'
(fpdir/(name+'.kicad_mod')).write_text(f)
name='DevKitC_38P_P2.54_W25.4_VERIFICAR'
f=fpstart(name,'REFERENCIA: DevKitC 38P, paso 2.54mm, hileras 25.4mm. Verificar ancho y orden fisico en el DevKit del usuario.','through_hole')
f+=rect(-13.97,-27.94,13.97,27.94,'F.Fab')+rect(-14.5,-28.5,14.5,28.5,'F.CrtYd',0.05)
f+='(fp_text user "USB / VERIFICAR" (at 0 25) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))))\n'
for side,start,x in [('L',1,-12.7),('R',20,12.7)]:
 for i in range(19):
  num=start+i;shape='rect' if num==1 else 'oval'
  f+=f'(pad {q(num)} thru_hole {shape} (at {x} {round(-22.86+i*2.54,4)}) (size 1.8 1.8) (drill 1) (layers "*.Cu" "*.Mask"))\n'
f+=')\n';(fpdir/(name+'.kicad_mod')).write_text(f)
(BASE/'documentacion'/'conexiones_esperadas.json').write_text(json.dumps(instances,indent=2))
(BASE/'documentacion'/'BOM.md').write_text('# Componentes - Receptor ASV, revision B preliminar\n\nU3 y U4 son modulos completos, no chips sueltos. J4 se monta solo para antena externa; no conectar dos antenas. Valores y encapsulados de pasivos deben respetar las tensiones indicadas.\n\n| Referencia | Valor / componente | Huella |\n|---|---|---|\n'+''.join(f'| {a} | {b} | {c} |\n' for a,b,c in bom)+'\nFusible de cable externo junto a bateria: 1 A, DC >=32 V, con portafusible adecuado; validar frente al consumo y arranque. No alimenta las placas externas.\n')
print('Generado:',BASE/'ReceptorASV.kicad_sch')
