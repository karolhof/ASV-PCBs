# Componentes - Receptor ASV, revision B preliminar

U3 y U4 son modulos completos, no chips sueltos. J4 se monta solo para antena externa; no conectar dos antenas. Valores y encapsulados de pasivos deben respetar las tensiones indicadas.

| Referencia | Valor / componente | Huella |
|---|---|---|
| J1 | BATERIA 12 V / 33 Ah | TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal |
| F1 | 1 A / >=32 V | Fuse:Fuse_1206_3216Metric |
| D1 | SS34 | Diode_SMD:D_SMA |
| D2 | SMBJ16A | Diode_SMD:D_SMB |
| C1 | 47u / 50 V | Capacitor_THT:CP_Radial_D6.3mm_P2.50mm |
| C2 | 10u / 50 V | Capacitor_SMD:C_1210_3225Metric |
| U1 | 12 V a 5 V / R-78E5.0-1.0 | Converter_DCDC:Converter_DCDC_RECOM_R-78E-0.5_THT |
| JP1 | PUENTE | Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical |
| C3 | 10u / 10 V | Capacitor_SMD:C_0805_2012Metric |
| C4 | 47u / 10 V | Capacitor_THT:CP_Radial_D5.0mm_P2.00mm |
| C5 | 1u / 10 V | Capacitor_SMD:C_0805_2012Metric |
| U2 | 5 V a 3,3 V / TLV75533 | Package_TO_SOT_SMD:SOT-23-5 |
| C6 | 10u / 10 V | Capacitor_SMD:C_0805_2012Metric |
| U3 | ESP32 DevKitC 38 pines | ASV_Receptor:DevKitC_38P_P2.54_W25.4_VERIFICAR |
| U4 | LoRa SX1278 / 433 MHz | ASV_Receptor:XL1278_SMT_SMD_VERIFICAR |
| R1 | 10k | Resistor_SMD:R_0805_2012Metric |
| R2 | 10k | Resistor_SMD:R_0805_2012Metric |
| J4 | ANTENA 433 MHz | Connector_Coaxial:SMA_Amphenol_132289_EdgeMount |
| C7 | 100n / 10 V | Capacitor_SMD:C_0805_2012Metric |
| C8 | 10u / 10 V | Capacitor_SMD:C_0805_2012Metric |
| J2 | STM32 1 | Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical |
| R3 | 100R | Resistor_SMD:R_0805_2012Metric |
| R4 | 100R | Resistor_SMD:R_0805_2012Metric |
| J3 | STM32 2 | Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical |
| R5 | 100R | Resistor_SMD:R_0805_2012Metric |
| R6 | 100R | Resistor_SMD:R_0805_2012Metric |

Fusible de cable externo junto a bateria: 1 A, DC >=32 V, con portafusible adecuado; validar frente al consumo y arranque. No alimenta las placas externas.
