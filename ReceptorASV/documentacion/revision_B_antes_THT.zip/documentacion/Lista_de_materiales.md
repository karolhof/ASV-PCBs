# Lista de materiales - una placa receptora ASV

Basada en el esquema ReceptorASV, revisión B. Cantidades para una placa, sin repuestos. Los encapsulados indicados corresponden a las huellas actuales; no sustituir por otros tamaños sin modificar la PCB.

| Cantidad | Material / especificación | Encapsulado o montaje | Referencias |
|---:|---|---|---|
| 1 | ESP32 DevKitC de 38 pines, con módulo WROOM | Placa completa; dos hileras de 19 pines | U3 |
| 1 | Módulo LoRa XL1278-SMT / SX1278, 433 MHz | Módulo completo soldado SMD | U4 |
| 1 | Convertidor DC-DC RECOM R-78E5.0-1.0, salida 5 V / 1 A | SIP-3, paso 2,54 mm | U1 |
| 1 | Regulador de 3,3 V TLV75533PDBVR | SOT-23-5 | U2 |
| 1 | Diodo Schottky SS34 | SMA / DO-214AC | D1 |
| 1 | Diodo TVS unidireccional SMBJ16A | SMB / DO-214AA | D2 |
| 1 | Fusible de 1 A, tensión nominal DC >=32 V | SMD 1206 | F1 |
| 1 | Capacitor electrolítico de 47 µF / 50 V | Radial, diámetro 6,3 mm, paso 2,5 mm | C1 |
| 1 | Capacitor cerámico de 10 µF / 50 V | SMD 1210 | C2 |
| 3 | Capacitor cerámico de 10 µF / 10 V | SMD 0805 | C3, C6, C8 |
| 1 | Capacitor electrolítico de 47 µF / 10 V | Radial, diámetro 5 mm, paso 2 mm | C4 |
| 1 | Capacitor cerámico de 1 µF / 10 V | SMD 0805 | C5 |
| 1 | Capacitor cerámico de 100 nF / 10 V | SMD 0805 | C7 |
| 2 | Resistencia de 10 kΩ, 1 %, al menos 0,125 W | SMD 0805 | R1, R2 |
| 4 | Resistencia de 100 Ω, 1 %, al menos 0,125 W | SMD 0805 | R3, R4, R5, R6 |
| 1 | Bornera de 2 posiciones, paso 5,08 mm, entrada horizontal; compatible con Phoenix MKDS 1,5/2-5,08 | THT | J1 |
| 2 | Tira macho de 3 pines, paso 2,54 mm | THT vertical | J2, J3 |
| 1 | Tira macho de 2 pines, paso 2,54 mm | THT vertical | JP1 |
| 1 | Puente removible (shunt) de 2 posiciones, paso 2,54 mm | Se coloca sobre JP1 | JP1 |

Para los cerámicos, seleccionar dieléctrico X7R o X5R y revisar la capacidad efectiva bajo polarización. Las tensiones son las nominales mínimas del diseño; una tensión mayor es admisible si se mantiene la huella y la capacidad adecuada. En los electrolíticos, comprobar diámetro y separación de patas, no solo capacidad y tensión.

## Antena: elegir una de las dos opciones

- **Antena de resorte del módulo:** una antena de 433 MHz, normalmente incluida con el módulo mostrado. En esta opción no montar J4 y evitar un ramal RF innecesario al rutear.
- **Antena externa:** un conector SMA Amphenol 132289 para borde de PCB (J4) y una antena de 433 MHz de 50 Ω con conector compatible. Retirar la antena de resorte del módulo. Verificar espesor de PCB y montaje del SMA antes de comprar.

No montar ambas antenas a la vez. La opción SMA es adicional y no está incluida en la tabla principal.

## Fuera de la PCB

| Cantidad | Material | Observación |
|---:|---|---|
| 1 | Batería AGM TAIYO TYD12-33, 12 V / 33 Ah | La batería indicada por el usuario; no volver a comprar si ya está disponible |
| 1 | Portafusible en línea con fusible de 1 A, nominal DC >=32 V | Cerca del borne positivo de batería; distinto de F1 |
| 1 juego | Cable positivo/negativo y terminales para batería y bornera | Longitud, sección y terminal de batería según montaje real |
| 2 | Arnés de 3 conductores para UART (TX, RX, GND) | Lado receptor compatible con J2/J3 de paso 2,54 mm; lado STM32 pendiente del modelo exacto |
| 1 | PCB del receptor | Pendiente de diseño físico y ruteo |

Las dos placas STM32 son externas y tienen alimentación propia; sus modelos no están especificados. No están incluidas como compra nueva.

## Montaje del DevKit

La tabla supone que el DevKit ya tiene sus dos hileras macho y se suelda a la PCB. Si se desea desmontable, agregar **dos tiras hembra de 19 posiciones, paso 2,54 mm**, comprobando separación entre hileras y altura. Son opcionales, no necesarias para el montaje soldado solicitado.

## Pendientes de compra/fabricación

- Confirmar el DevKit de 38 pines y su ancho real.
- Cotejar pinout y huella del módulo LoRa físico. Se usa la referencia XL1278-SMT de 16 contactos, aún pendiente de validación física.
- Confirmar niveles UART de 3,3 V y conectores de las STM32.
- U1 es un convertidor conmutado RECOM; un 7805 lineal no es un reemplazo directo validado para este diseño.
- Seleccionar el número de parte concreto de los fusibles y comprobar curva de apertura frente al arranque.

Esta lista documenta el esquema preliminar; no incluye precios ni disponibilidad comercial verificada.
