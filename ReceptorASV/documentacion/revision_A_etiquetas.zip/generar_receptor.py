#!/usr/bin/env python3
"""Genera el esquema KiCad y bibliotecas locales del receptor ASV (revision A preliminar)."""
from pathlib import Path
import re, json, uuid, math, copy
BASE=Path(__file__).resolve().parent
STD=Path('/Applications/KiCad/KiCad.app/Contents/SharedSupport/symbols')
q=lambda s:json.dumps(str(s),ensure_ascii=False)
u=lambda:str(uuid.uuid4())
def parse(s):
 ts=iter(re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',s))
 def sub():
  out=[]
  for t in ts:
   if t=='(':out.append(sub())
   elif t==')':return out
   else:out.append(t)
  return out
 return sub()[0]
def dump(x):return '('+' '.join(map(dump,x))+')' if isinstance(x,list) else str(x)
def child(x,key):return next((t for t in x if isinstance(t,list) and t[0]==key),None)
def kids(x,key):return [t for t in x if isinstance(t,list) and t[0]==key]
def val(x):return json.loads(x) if x.startswith('"') else x
libs={}; custom={}
def standard(lib,name):
 key=lib+':'+name
 if key in libs:return key
 root=parse((STD/(lib+'.kicad_sym')).read_text())
 syms={val(t[1]):t for t in kids(root,'symbol')}
 def expand(n):
  s=copy.deepcopy(syms[n]); ext=child(s,'extends')
  if ext:
   parentname=val(ext[1]); parent=expand(parentname)
   ownprops={val(p[1]) for p in kids(s,'property')}
   body=[t for t in parent[2:] if not (isinstance(t,list) and (t[0]=='property' and val(t[1]) in ownprops))]
   for t in body:
    if isinstance(t,list) and t[0]=='symbol':t[1]=q(val(t[1]).replace(parentname+'_',n+'_'))
   s=['symbol',q(n)]+body+[t for t in s[2:] if not(isinstance(t,list) and t[0]=='extends')]
  return s
 s=expand(name);s[1]=q(key);libs[key]=s;return key
def block(name,pins,w,h):
 # pins: number, name, electrical type, side L/R/T/B, local coordinate along side
 s=['symbol',q(name),['pin_names',['offset','0.8']],['in_bom','yes'],['on_board','yes']]
 for n,v in [('Reference','U'),('Value',name),('Footprint',''),('Datasheet','')]:
  s.append(parse(f'(property {q(n)} {q(v)} (at 0 0 0) (effects (font (size 1.27 1.27)) (hide yes)))'))
 s.append(parse(f'(symbol {q(name+"_0_1")} (rectangle (start {-w} {h}) (end {w} {-h}) (stroke (width 0.254) (type default)) (fill (type background))))'))
 body=['symbol',q(name+'_1_1')]
 for num,pn,typ,side,co in pins:
  x,y,ang={'L':(-w-5.08,co,0),'R':(w+5.08,co,180),'T':(co,h+5.08,270),'B':(co,-h-5.08,90)}[side]
  body.append(parse(f'(pin {typ} line (at {x} {y} {ang}) (length 5.08) (name {q(pn)} (effects (font (size 1.016 1.016)))) (number {q(num)} (effects (font (size 0.889 0.889)))))'))
 s.append(body);custom[name]=copy.deepcopy(s);s[1]=q('ASV_Receptor:'+name);libs['ASV_Receptor:'+name]=s;return 'ASV_Receptor:'+name
# Numbering follows the user's existing DevKitC symbol; row pitch/spacing remain to be checked on the physical board.
left=['3V3','EN','GPIO36','GPIO39','GPIO34','GPIO35','GPIO32','GPIO33','GPIO25','GPIO26','GPIO27','GPIO14','GPIO12','GND','GPIO13','SD2','SD3','CMD','5V']
right=['GND','GPIO23','GPIO22','TX0','RX0','GPIO21','GND','GPIO19','GPIO18','GPIO5','GPIO17','GPIO16','GPIO4','GPIO0','GPIO2','GPIO15','SD1','SD0','CLK']
pins=[]
for side,names,start in [('L',left,1),('R',right,20)]:
 for i,pn in enumerate(names):
  typ='power_in' if pn in ['GND','5V'] else 'power_out' if pn=='3V3' else 'input' if pn in ['EN','GPIO36','GPIO39','GPIO34','GPIO35'] else 'bidirectional'
  pins.append((str(start+i),pn,typ,side,round(34.29-i*3.81,4)))
esp=block('DevKitC_38P_VERIFICAR',pins,16.51,38.1)
lora=block('XL1278_SMT_433_VERIFICAR',[
 ('5','VCC_3V3','power_in','L',22.86),('8','SCK','input','L',15.24),('7','MOSI','input','L',11.43),('6','MISO','output','L',7.62),('9','NSS','input','L',3.81),('11','RESET','input','L',0),('10','DIO0','bidirectional','L',-3.81),('2','DIO1','bidirectional','L',-7.62),('3','DIO2','bidirectional','L',-11.43),('1','GND','power_in','L',-19.05),('12','GND','power_in','L',-22.86),
 ('16','ANT','passive','R',22.86),('15','GND_RF','power_in','R',19.05),('4','DIO3','bidirectional','R',3.81),('13','DIO4','bidirectional','R',0),('14','DIO5','bidirectional','R',-3.81)],15.24,27.94)
buck=block('R78E5V_1A',[('1','VIN','power_in','L',0),('3','5V_OUT','power_out','R',0),('2','GND','power_in','B',0)],13.97,7.62)
ldo=block('TLV75533PDBV',[('1','IN','power_in','L',2.54),('3','EN','input','L',-2.54),('5','OUT','power_out','R',2.54),('2','GND','power_in','B',0),('4','NC','no_connect','R',-2.54)],10.16,6.35)
uart=block('UART_3V3',[('1','GND','passive','L',3.81),('2','TX_ESP','passive','L',0),('3','RX_ESP','passive','L',-3.81)],7.62,7.62)
bat=block('BATERIA_12V',[('1','BAT+','passive','R',2.54),('2','BAT-','passive','R',-2.54)],7.62,6.35)
for n in ['R','C','C_Polarized','D_Schottky','D_Zener','Fuse']:standard('Device',n)
standard('Connector_Generic','Conn_01x02');standard('Connector','Conn_Coaxial');standard('power','PWR_FLAG')
root=u(); elements=[]; instances={}; bom=[]
def fx(size=1.27,justify=''):return f'(effects (font (size {size} {size}))'+(f' (justify {justify})' if justify else '')+')'
def note(txt,x,y,size=1.27):elements.append(f'(text {q(txt)} (at {x} {y} 0) {fx(size,"left top")} (uuid {q(u())}))')
def wire(p1,p2):
 if p1==p2:return
 elements.append(f'(wire (pts (xy {p1[0]} {p1[1]}) (xy {p2[0]} {p2[1]})) (stroke (width 0) (type default)) (uuid {q(u())}))')
def label(net,p,side='R'):
 elements.append(f'(label {q(net)} (at {p[0]} {p[1]} 0) {fx(1.27,"right bottom" if side=="L" else "left bottom")} (uuid {q(u())}))')
def put(key,ref,value,x,y,rot=0,foot='',datasheet='',props=None):
 sym=libs[key]; iid=u(); pts={}; angles={}
 for body in kids(sym,'symbol'):
  for p in kids(body,'pin'):
   a=child(p,'at'); px,py=float(a[1]),float(a[2]); rad=math.radians(rot)
   coord=(round(x+px*math.cos(rad)-py*math.sin(rad),4),round(y-py*math.cos(rad)-px*math.sin(rad),4))
   num=val(child(p,'number')[1]);pts[num]=coord;angles[num]=(float(a[3])+rot)%360
 # Use generous property separation for blocks; small parts put labels beside vertical bodies.
 if props is None:
  if key.startswith('ASV_Receptor:'):
   hh={'DevKitC_38P_VERIFICAR':38.1,'XL1278_SMT_433_VERIFICAR':27.94,'R78E5V_1A':7.62,'TLV75533PDBV':6.35,'UART_3V3':7.62,'BATERIA_12V':6.35}[key.split(':')[1]]
   props=[(x,y-hh-7.62),(x,y-hh-3.81)]
  elif key in ['Device:C','Device:C_Polarized','Device:R','Device:Fuse'] and rot==0:props=[(x+4,y-1.27),(x+4,y+1.27)]
  else:props=[(x,y-7.62),(x,y-3.81)]
 ps=''
 for k,v,pos,hide in [('Reference',ref,props[0],False),('Value',value,props[1],False),('Footprint',foot,(x,y),True),('Datasheet',datasheet,(x,y),True)]:
  just='left' if key in ['Device:C','Device:C_Polarized','Device:R','Device:Fuse'] and rot==0 and not hide else ''
  effects=fx(1.27,just)
  if hide:effects=effects[:-1]+' (hide yes))'
  ps+=f'(property {q(k)} {q(v)} (at {pos[0]} {pos[1]} {90 if rot in (90,270) else 0}) {effects})'
 pn=''.join(f'(pin {q(n)} (uuid {q(u())}))' for n in pts)
 elements.append(f'(symbol (lib_id {q(key)}) (at {x} {y} {rot}) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {q(iid)}) {ps} {pn} (instances (project "ReceptorASV" (path {q("/"+root)} (reference {q(ref)}) (unit 1)))))')
 instances[ref]={'pins':pts,'angles':angles,'nets':{},'value':value,'footprint':foot}
 if not ref.startswith('#'):bom.append((ref,value,foot))
 return ref
def connect(ref,pin,net,length=5.08):
 pin=str(pin);i=instances[ref];p=i['pins'][pin];ang=i['angles'][pin]
 dx,dy={0:(-1,0),180:(1,0),90:(0,1),270:(0,-1)}[ang]
 e=(round(p[0]+length*dx,4),round(p[1]+length*dy,4));wire(p,e);label(net,e,'L' if dx<0 else 'R');i['nets'][pin]=net
 return e
def nc(ref,pin):
 p=instances[ref]['pins'][str(pin)];elements.append(f'(no_connect (at {p[0]} {p[1]}) (uuid {q(u())}))');instances[ref]['nets'][str(pin)]='NC'
def flag(ref,x,y,net):
 put('power:PWR_FLAG',ref,'PWR_FLAG',x,y,props=[(x,y-5),(x,y-2)])
 connect(ref,'1',net,2.54)
CAP='Capacitor_SMD:C_0805_2012Metric';RES='Resistor_SMD:R_0805_2012Metric'
# Power: left to right, labelled nets are electrically connected throughout this sheet.
note('RECEPTOR ASV | ESP32 + LoRa 433 MHz + 2 UART',15.24,12.7,2.54)
note('REV A - ESQUEMA PRELIMINAR. Cotejar modulo, huellas y niveles UART antes de fabricar.',15.24,19.05,1.524)
note('1. ENTRADA AGM 12 V / 33 Ah Y CONVERSION A 5 V',15.24,27.94,1.524)
put(bat,'J1','BORNERA 12 V',25.4,48.26,foot='TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal')
connect('J1',2,'GND')
put('Device:Fuse','F1','1 A / >=32 V',63.5,45.72,90,'Fuse:Fuse_1206_3216Metric')

put('Device:D_Schottky','D1','SS34',104.14,45.72,180,'Diode_SMD:D_SMA')

# standard Schottky orientation (cathode left) is schematic only; nets define actual polarity.
put('Device:D_Zener','D2','SMBJ16A',134.62,68.58,270,'Diode_SMD:D_SMB',datasheet='https://www.vishay.com/docs/88392/smbj.pdf',props=[(145,67.31),(145,71.12)])
connect('D2',1,'VIN_PROT');connect('D2',2,'GND')
put('Device:C_Polarized','C1','47u / 50 V',165.1,76.2,foot='Capacitor_THT:CP_Radial_D6.3mm_P2.50mm')
connect('C1',1,'VIN_PROT');connect('C1',2,'GND')
put('Device:C','C2','10u / 50 V',198.12,76.2,foot='Capacitor_SMD:C_1210_3225Metric')
connect('C2',1,'VIN_PROT');connect('C2',2,'GND')
put(buck,'U1','R-78E5.0-1.0',170.18,45.72,foot='Converter_DCDC:Converter_DCDC_RECOM_R-78E-0.5_THT',datasheet='https://recom-power.com/pdf/Innoline/R-78E-1.0.pdf')
connect('U1',3,'BUCK_5V');connect('U1',2,'GND',2.54)
for ra,pa,rb,pb,net in [('J1','1','F1','1','BAT_POS'),('F1','2','D1','2','BAT_FUSED'),('D1','1','U1','1','VIN_PROT')]:
 a=instances[ra]['pins'][pa];b=instances[rb]['pins'][pb];wire(a,b)
 label(net,((a[0]+b[0])/2,a[1]));instances[ra]['nets'][pa]=net;instances[rb]['nets'][pb]=net
put('Connector_Generic:Conn_01x02','JP1','PUENTE BATERIA',241.3,43.18,foot='Connector_PinHeader_2.54mm:PinHeader_1x02_P2.54mm_Vertical',props=[(241.3,33.02),(241.3,36.83)])
connect('JP1',1,'BUCK_5V');connect('JP1',2,'SYS_5V')
put('Device:C','C3','10u / 10 V',241.3,76.2,foot=CAP);connect('C3',1,'SYS_5V');connect('C3',2,'GND')
put('Device:C_Polarized','C4','47u / 10 V',274.32,76.2,foot='Capacitor_THT:CP_Radial_D5.0mm_P2.00mm');connect('C4',1,'SYS_5V');connect('C4',2,'GND')
note('JP1 cerrado: bateria. Abrir JP1 ANTES de conectar USB.\nCon JP1 abierto, USB del DevKit alimenta SYS_5V y LoRa.\nConfirmar esquema de alimentacion del DevKit real.',208.28,86.36,1.27)
note('Fusible externo adicional junto al borne + de la bateria (protege el cable).\nF1 protege esta placa. Sin cargador ni corte automatico por baja bateria.\nEntrada prevista: 10,5 a 14,7 V. Verificar arranque e inrush del buck.',15.24,86.36,1.27)
note('2. 3,3 V EXCLUSIVOS PARA EL RADIO',302.26,27.94,1.524)
put(ldo,'U2','TLV75533PDBVR',345.44,48.26,foot='Package_TO_SOT_SMD:SOT-23-5',datasheet='https://www.ti.com/lit/ds/symlink/tlv755p.pdf')
connect('U2',1,'SYS_5V');connect('U2',3,'SYS_5V');connect('U2',5,'LORA_3V3');connect('U2',2,'GND',2.54);nc('U2',4)
put('Device:C','C5','1u / 10 V',312.42,73.66,foot=CAP);connect('C5',1,'SYS_5V');connect('C5',2,'GND')
put('Device:C','C6','10u / 10 V',368.3,73.66,foot=CAP);connect('C6',1,'LORA_3V3');connect('C6',2,'GND')
note('C5/C6 pegados al LDO. No unir LORA_3V3 al 3V3 del DevKit.',302.26,88.9,1.27)
# ESP32
note('3. DEVKIT SOBRE LA PCB',15.24,106.68,1.524)
put(esp,'U3','ESP32 DevKitC 38P (*)',78.74,168.91,foot='ASV_Receptor:DevKitC_38P_P2.54_W25.4_VERIFICAR')
espnets={'19':'SYS_5V','14':'GND','20':'GND','26':'GND','28':'LORA_SCK','27':'LORA_MISO','21':'LORA_MOSI','11':'LORA_NSS','12':'LORA_RESET','10':'LORA_DIO0','9':'LORA_DIO1','8':'LORA_DIO2','25':'UART1_TX','22':'UART1_RX','30':'UART2_TX','31':'UART2_RX'}
for pin in instances['U3']['pins']:
 if pin in espnets:connect('U3',pin,espnets[pin],5.08)
 else:nc('U3',pin)
# Radio
note('4. MODULO LoRa SOLDADO SMD',175.26,106.68,1.524)
put(lora,'U4','XL1278-SMT / SX1278 (*)',231.14,157.48,foot='ASV_Receptor:XL1278_SMT_SMD_VERIFICAR')
loranets={'1':'GND','12':'GND','15':'GND','5':'LORA_3V3','8':'LORA_SCK','7':'LORA_MOSI','6':'LORA_MISO','9':'LORA_NSS','11':'LORA_RESET','10':'LORA_DIO0','2':'LORA_DIO1','3':'LORA_DIO2','16':'RF_433'}
for pin in instances['U4']['pins']:
 if pin in loranets:connect('U4',pin,loranets[pin])
 else:nc('U4',pin)
put('Connector:Conn_Coaxial','J4','ANT 433 MHz',285.75,134.62,foot='Connector_Coaxial:SMA_Amphenol_132289_EdgeMount',props=[(285.75,123.19),(285.75,127)])
connect('J4',1,'RF_433');connect('J4',2,'GND')
note('J4 opcional: montar SOLO si se retira\nla antena del modulo. Una sola antena.\nRF: pista 50 ohm corta, plano GND.\nPin 16 = ANT; 12 y 15 = GND (*).',271.78,154.94,1.27)
put('Device:C','C7','100n / 10 V',185.42,208.28,foot=CAP);connect('C7',1,'LORA_3V3');connect('C7',2,'GND')
put('Device:C','C8','10u / 10 V',218.44,208.28,foot=CAP);connect('C8',1,'LORA_3V3');connect('C8',2,'GND')
put('Device:R','R1','10k',251.46,208.28,foot=RES);connect('R1',1,'LORA_3V3');connect('R1',2,'LORA_NSS')
put('Device:R','R2','10k',284.48,208.28,foot=RES);connect('R2',1,'LORA_3V3');connect('R2',2,'LORA_RESET')
note('C7/C8 junto al pin VCC del modulo. Pull-ups en NSS y RESET.',175.26,226.06,1.27)
# Independent UARTs
note('5. DOS UART LOGICAS DE 3,3 V (*)',325.12,106.68,1.524)
for n,y in [(1,137.16),(2,180.34)]:
 ref='J'+str(n+1);put(uart,ref,'STM32 '+str(n)+' / UART 3V3',383.54,y,foot='Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical')
 connect(ref,1,'GND');connect(ref,2,f'EXT{n}_RX');connect(ref,3,f'EXT{n}_TX')
 for j,dy in enumerate([0,15.24]):
  rr='R'+str(3+(n-1)*2+j);put('Device:R',rr,'100R',335.28,y+dy,90,RES)
  # R has pin 1 to right at 90 degrees; direction does not matter electrically.
  connect(rr,1,f'UART{n}_'+('TX' if j==0 else 'RX'),2.54)
  connect(rr,2,f'EXT{n}_'+('RX' if j==0 else 'TX'),2.54)
note('J2/J3: 1 GND | 2 TX del ESP | 3 RX del ESP\nCruzar TX hacia RX en la placa externa.\nLas dos STM32 tienen alimentacion propia.\n100R son resistencias serie, NO adaptan niveles.\nConfirmar UART TTL 3,3 V (no 5 V / RS-232).',320.04,208.28,1.27)
# Electrical input-source declarations (not physical parts).
flag('#FLG01',43.18,238.76,'GND');flag('#FLG02',83.82,238.76,'VIN_PROT');flag('#FLG03',129.54,238.76,'SYS_5V')
note('(*) PENDIENTES PARA LIBERAR PCB',15.24,251.46,1.524)
note('Confirmar DevKit de 38 pines y separacion entre hileras (referencia: 25,4 mm).\nConfirmar modulo XL1278-SMT: 16 contactos, 16,5 x 17 mm, paso 1,27 mm.\nHuellas U3/U4 de referencia: imprimir 1:1 y cotejar con las placas reales.\nConfirmar modelo STM32, UART 3V3 y masa comun entre placas.\nEl esquema supera ERC solo cuando el reporte adjunto asi lo indica; no implica ensayo fisico.',15.24,257.81,1.27)
note('ASIGNACION DE FIRMWARE\nSPI: SCK=18, MISO=19, MOSI=23, NSS=27\nLoRa: RESET=14, DIO0=26, DIO1=25, DIO2=33\nUART1: TX=21, RX=22 | UART2: TX=17, RX=16\nUART0 queda para USB/programacion. Solo ESP32-WROOM.',175.26,238.76,1.27)
# Serialize self-contained schematic and local symbol library.
header=f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {q(root)}) (paper "A3") (title_block (title "ASV - Receptor LoRa 433 MHz") (date "2026-10-05") (rev "A") (company "UCC - ASV") (comment 1 "Bateria AGM 12 V / ESP32 DevKit / dos UART 3V3") (comment 2 "Huellas U3 y U4 requieren cotejo fisico"))'
(BASE/'ReceptorASV.kicad_sch').write_text(header+'\n(lib_symbols\n'+'\n'.join(dump(s) for s in libs.values())+')\n'+'\n'.join(elements)+f'\n(sheet_instances (path "/" (page "1")))\n)\n')
(BASE/'ASV_Receptor.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor")\n'+'\n'.join(dump(s) for s in custom.values())+'\n)')
(BASE/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "ASV_Receptor") (type "KiCad") (uri "${KIPRJMOD}/ASV_Receptor.kicad_sym") (options "") (descr "Simbolos locales receptor ASV")))\n')
(BASE/'fp-lib-table').write_text('(fp_lib_table (version 7) (lib (name "ASV_Receptor") (type "KiCad") (uri "${KIPRJMOD}/ASV_Receptor.pretty") (options "") (descr "Huellas de referencia: verificar antes de fabricar")))\n')
if not (BASE/'ReceptorASV.kicad_pro').exists():
 (BASE/'ReceptorASV.kicad_pro').write_text(json.dumps({'meta':{'filename':'ReceptorASV.kicad_pro','version':1},'net_settings':{'classes':[{'name':'Default','clearance':0.2,'track_width':0.25,'via_diameter':0.6,'via_drill':0.3,'microvia_diameter':0.3,'microvia_drill':0.1,'diff_pair_width':0.2,'diff_pair_gap':0.25,'diff_pair_via_gap':0.25}],'meta':{'version':4}}},indent=2))
# Own footprint construction from documented reference geometry; no invented claim of manufacturing validation.
fpdir=BASE/'ASV_Receptor.pretty';fpdir.mkdir(exist_ok=True)
def fpstart(name,desc,attr):return f'(footprint {q(name)} (version 20241229) (generator "pcbnew") (layer "F.Cu") (descr {q(desc)}) (attr {attr})\n(property "Reference" "REF**" (at 0 -11 0) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))))\n(property "Value" {q(name)} (at 0 12 0) (layer "F.Fab") (effects (font (size 0.8 0.8) (thickness 0.12))))\n'
def rect(x1,y1,x2,y2,layer,width=0.1):return f'(fp_rect (start {x1} {y1}) (end {x2} {y2}) (stroke (width {width}) (type default)) (fill none) (layer {q(layer)}))\n'
name='XL1278_SMT_SMD_VERIFICAR'
f=fpstart(name,'REFERENCIA NO LIBERADA. XL1278-SMT 16 contactos. 16.5x17mm, paso 1.27. Cotejar modulo fisico. Geometria referencia: matburnham/kicad-libs.','smd')
# Local coordinates translated from measured reference; origin is the body center.
ox,oy=6.985,7.7
f+=rect(-8.25,-8.5,8.25,8.5,'F.Fab')+rect(-9.65,-9,9.65,10,'F.CrtYd',0.05)
f+='(fp_line (start -7 -8.75) (end 7 -8.75) (stroke (width 0.12) (type default)) (layer "F.SilkS"))\n'
f+='(fp_text user "VERIFICAR" (at 0 0) (layer "F.Fab") (effects (font (size 1 1) (thickness 0.15))))\n'
coords={i:(-0.8,(i-1)*1.27,0) for i in range(1,13)}
coords.update({13:(0.37,16.029,90),14:(1.64,16.029,90),15:(14.748,1.27,0),16:(14.748,0,0)})
for num,(x,y,a) in coords.items():
 f+=f'(pad {q(num)} smd roundrect (at {round(x-ox,4)} {round(y-oy,4)} {a}) (size 2.4 0.9) (layers "F.Cu" "F.Paste" "F.Mask") (roundrect_rratio 0.2))\n'
f+='(fp_circle (center -9.5 -7.7) (end -9.25 -7.7) (stroke (width 0.15) (type default)) (fill none) (layer "F.SilkS"))\n)\n'
(fpdir/(name+'.kicad_mod')).write_text(f)
name='DevKitC_38P_P2.54_W25.4_VERIFICAR'
f=fpstart(name,'REFERENCIA: DevKitC 38P, paso 2.54mm, hileras 25.4mm. Verificar ancho y orden fisico en el DevKit del usuario.','through_hole')
f+=rect(-13.97,-27.94,13.97,27.94,'F.Fab')+rect(-14.5,-28.5,14.5,28.5,'F.CrtYd',0.05)
f+='(fp_text user "USB / VERIFICAR" (at 0 25) (layer "F.SilkS") (effects (font (size 1 1) (thickness 0.15))))\n'
for side,start,x in [('L',1,-12.7),('R',20,12.7)]:
 for i in range(19):
  num=start+i;shape='rect' if num==1 else 'oval'
  f+=f'(pad {q(num)} thru_hole {shape} (at {x} {round(-22.86+i*2.54,4)}) (size 1.8 1.8) (drill 1) (layers "*.Cu" "*.Mask"))\n'
f+=')\n';(fpdir/(name+'.kicad_mod')).write_text(f)
(BASE/'documentacion'/'conexiones_esperadas.json').write_text(json.dumps(instances,indent=2))
(BASE/'documentacion'/'BOM.md').write_text('# Componentes - Receptor ASV, revision A preliminar\n\nU3 y U4 son modulos completos, no chips sueltos. J4 se monta solo para antena externa; no conectar dos antenas. Valores y encapsulados de pasivos deben respetar las tensiones indicadas.\n\n| Referencia | Valor / componente | Huella |\n|---|---|---|\n'+''.join(f'| {a} | {b} | {c} |\n' for a,b,c in bom)+'\nFusible de cable externo junto a bateria: 1 A, DC >=32 V, con portafusible adecuado; validar frente al consumo y arranque. No alimenta las placas externas.\n')
print('Generado:',BASE/'ReceptorASV.kicad_sch')
